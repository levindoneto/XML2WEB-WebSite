# XML2WEB
Conversor de arquivos .XML gerados pela plataforma Lattes em páginas Web.
